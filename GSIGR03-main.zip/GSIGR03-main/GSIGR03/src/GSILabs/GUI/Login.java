/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSILabs.GUI;

import GSILabs.BModel.*;
import GSILabs.BSystem.BusinessSystem;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author alumno
 */
public class Login {

    public static Cliente c1;
    public static Propietario admin1;

    public static void main(String args[]) {
        BusinessSystem system = introduccionDatosEjemplo();
        
        /*c1 = new Cliente("anfetik", "123", "2020/01/01");
        system.nuevoUsuario(c1);
        iniciarGUI(c1,system);*/
        
        admin1 = new Propietario("DanielV", "1232", "2020/02/01");
        system.nuevoUsuario(admin1);
        iniciarGUIAdmin(admin1,system);
        
    }
    
    public static void iniciarGUI(Cliente c, BusinessSystem system){
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                GUICliente cliente = new GUICliente(c1, system);
                cliente.setVisible(true);
                cliente.setLocationRelativeTo(null);
                
            }
        });
    }
    
    public static void iniciarGUIAdmin(Propietario p, BusinessSystem system){
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                GUIAdmin propietario = new GUIAdmin(admin1, system);
                propietario.setVisible(true);
                propietario.setLocationRelativeTo(null);
                
            }
        });
    }
    private static BusinessSystem introduccionDatosEjemplo() {
        /* Instancia de BussinessSystem*/
        BusinessSystem system = new BusinessSystem();
        
        /* Bares */
        Bar b1 = new Bar("Cañas", "Comunidad Foral de Navarra, Navarra, Calle Perez Goyena, 16", "Muy malo y bueno");
        b1.tags.add("calamares");
        b1.tags.add("tarta");
        b1.tags.add("chuleton");
        system.nuevoLocal(b1);
        Bar b2 = new Bar("Erreleku", "Comunidad Foral de Navarra, Navarra, Cordovilla, 45", "Muy malo y bueno");
        b2.tags.add("ensalada");
        b2.tags.add("ventresca con aceitillo");
        b2.tags.add("butifarra");
        system.nuevoLocal(b2);
        Bar b3 = new Bar("Aintzane", "Comunidad Foral de Navarra, Navarra, Barañain, 2", "Muy malo y bueno");
        b3.tags.add("fabada");
        system.nuevoLocal(b3);
        Bar b4 = new Bar("Goñi", "Comunidad Foral de Navarra, Navarra, Beriain, 32", "Muy malo y bueno");
        b4.tags.add("caravinero fresco del cantabrico");
        b4.tags.add("pulpo gallego con patatas panaderas");
        b4.tags.add("confit de conejo con romero y tomillo");
        b4.tags.add("croquetas");
        b4.tags.add("caracoles");
        system.nuevoLocal(b4);

        /* Restaurantes */
        Restaurante r1 = new Restaurante("18", "50", "5", "Goiko", "Comunidad Foral de Navarra, Navarra, Paseo Sarasate, 1", "Muy malo y bueno");
        system.nuevoLocal(r1);
        Restaurante r2 = new Restaurante("13", "20", "5", "Bodeguita", "Comunidad Foral de Navarra, Navarra, Calle mayor, 89", "Muy malo y bueno");
        system.nuevoLocal(r2);
        Restaurante r3 = new Restaurante("20", "100", "10", "Asador mutiloa", "Comunidad Foral de Navarra, Navarra, Zizur, 26", "Muy malo y bueno");
        system.nuevoLocal(r3);

        /* Pubs */
        Pub p1 = new Pub("20:00", "05:00", "Kaixo", "Comunidad Foral de Navarra, Navarra, Calle almendra, 3", "Muy malo y bueno");
        system.nuevoLocal(p1);
        Pub p2 = new Pub("15:00", "24:00", "Irish", "Comunidad Foral de Navarra, Navarra, Esquiroz, 54", "Muy malo y bueno");
        system.nuevoLocal(p2);
        Pub p3 = new Pub("24:00", "07:00", "Canalla", "Comunidad Foral de Navarra, Navarra, Calle extintor, 45", "Muy malo y bueno");
        system.nuevoLocal(p3);
        Pub p4 = new Pub("17:00", "22:00", "La Esquina", "Comunidad Foral de Navarra, Navarra, PLaza del castillo, 69", "Muy malo y bueno");
        system.nuevoLocal(p4);

        /* Propietarios */
        Propietario d1 = new Propietario("Daniel", "1234", "24/05/1980");
        system.nuevoUsuario(d1);
        Propietario d2 = new Propietario("ivan", "Almendras123", "21/07/1999");
        system.nuevoUsuario(d2);
        Propietario d3 = new Propietario("Alex", "extintor", "20/01/2003");
        system.nuevoUsuario(d3);
        Propietario d4 = new Propietario("Oscar", "si", "08/2/1991");
        system.nuevoUsuario(d4);
        Propietario d5 = new Propietario("Luis", "no", "01/01/1988");
        system.nuevoUsuario(d5);
        Propietario d6 = new Propietario("Miguel", "contraseña", "12/12/2000");
        system.nuevoUsuario(d6);


        /* Asociación propietarios con locales*/
        system.asociarLocal(b1, d1);
        system.asociarLocal(b2, d2);
        system.asociarLocal(r1, d2);
        system.asociarLocal(p1, d2);
        system.asociarLocal(r2, d3);
        system.asociarLocal(r3, d3);
        system.asociarLocal(p2, d4);
        system.asociarLocal(p3, d4);
        system.asociarLocal(p4, d4);
        system.asociarLocal(b3, d5);
        system.asociarLocal(b4, d6);
        system.asociarLocal(b1, d6);
        system.asociarLocal(p2, d6);
        system.asociarLocal(p4, d6);
        system.asociarLocal(r3, d6);
        system.asociarLocal(b4, d6);
        
        /* Clientes */
        Cliente cliente1 = new Cliente("Luis", "1234", "2001/12/01");
        system.nuevoUsuario(cliente1);
        system.nuevaReserva(cliente1, b1, LocalDate.now(), LocalTime.NOON);

        Cliente cliente2 = new Cliente("Maria", "1234", "2001/12/01");
        system.nuevoUsuario(cliente2);
        system.nuevaReserva(cliente2, b2, LocalDate.now(), LocalTime.NOON);

        Cliente cliente3 = new Cliente("Pedro", "1234", "2001/12/01");
        system.nuevoUsuario(cliente3);
        system.nuevaReserva(cliente3, b3, LocalDate.now(), LocalTime.NOON);

        Cliente cliente4 = new Cliente("Iñaki", "1234", "2001/12/01");
        system.nuevoUsuario(cliente4);
        Cliente cliente5 = new Cliente("Dani", "1234", "2001/12/01");
        system.nuevoUsuario(cliente5);
        Cliente cliente6 = new Cliente("Diego", "1234", "2001/12/01");
        system.nuevoUsuario(cliente6);
        
        /*Reservas*/
        system.nuevaReserva(cliente4, b1, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente4, b2, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente4, b4, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente5, b4, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente5, b3, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente6, b4, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente6, b1, LocalDate.now(), LocalTime.NOON);

        system.nuevaReserva(cliente4, r1, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente4, r2, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente4, r3, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente5, r1, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente5, r3, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente6, r2, LocalDate.now(), LocalTime.NOON);
        system.nuevaReserva(cliente6, r1, LocalDate.now(), LocalTime.NOON);
        
        
        /* Reviews */
        Review review1 = new Review(cliente2.nick,"Muy rico", r1);
        review1.valoracion = 3;
        system.nuevaReview(review1);
        Contestacion c1 = new Contestacion(review1, d2, "gracias");
        system.nuevaContestacion(c1, review1);
        
        Review review2 = new Review(cliente4.nick,"Muy rico", r2);
        review2.valoracion = 2;
        system.nuevaReview(review2);
        Contestacion c2 = new Contestacion(review2, d3, "gracias");
        system.nuevaContestacion(c2, review2);
        
        Review review3 = new Review(cliente5.nick,"Muy rico", r3);
        review3.valoracion = 5;
        system.nuevaReview(review3);
        Contestacion c3 = new Contestacion(review3, d3, "gracias");
        system.nuevaContestacion(c3, review3);
        
        Review review4 = new Review(cliente3.nick,"Muy rico", p1);
        review4.valoracion = 5;
        system.nuevaReview(review4);
        Contestacion c4 = new Contestacion(review4, d2, "gracias");
        system.nuevaContestacion(c4, review4);
        
        Review review5 = new Review(cliente1.nick,"Muy rico", p2);
        review5.valoracion = 4;
        system.nuevaReview(review5);
        Contestacion c5 = new Contestacion(review5, d6, "gracias");
        system.nuevaContestacion(c5, review5);
        
        Review review6 = new Review(cliente1.nick,"Muy rico", p3);
        review6.valoracion = 2;
        system.nuevaReview(review6);
        Contestacion c6 = new Contestacion(review6, d4, "gracias");
        system.nuevaContestacion(c6, review6);
        
        Review review7 = new Review(cliente5.nick,"Muy rico", p4);
        review7.valoracion = 4;
        system.nuevaReview(review7);
        Contestacion c7 = new Contestacion(review7, d6, "gracias");
        system.nuevaContestacion(c7, review7);
        
        Review review8 = new Review(cliente6.nick,"Muy rico", b1);
        review8.valoracion = 1;
        system.nuevaReview(review8);
        Contestacion c8 = new Contestacion(review8, d1, "gracias");
        system.nuevaContestacion(c8, review8);
        
        Review review9 = new Review(cliente3.nick,"Muy rico", b2);
        review9.valoracion = 3;
        system.nuevaReview(review9);
        Contestacion c9 = new Contestacion(review9, d2, "gracias");
        system.nuevaContestacion(c9, review9);
        
        Review review10 = new Review(cliente2.nick,"Muy rico", b3);
        review10.valoracion = 1;
        system.nuevaReview(review10);
        Contestacion c10 = new Contestacion(review10, d5, "gracias");
        system.nuevaContestacion(c10, review10);
        
        Review review11 = new Review(cliente4.nick,"Muy rico", b4);
        review11.valoracion = 3;
        system.nuevaReview(review11);
        Contestacion c11 = new Contestacion(review11, d6, "gracias");
        system.nuevaContestacion(c11, review11);
        
        return system;
    }
}
