/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSILabs.BModel;

/**
 *
 * @author alumno
 */
public class Contestacion {
    Review r; //Review a la que se esta contestando
    Usuario u; //Usuario que esta respondiendo la review
    String respuesta; //La respuesta del dueño del local sobre la review
}
