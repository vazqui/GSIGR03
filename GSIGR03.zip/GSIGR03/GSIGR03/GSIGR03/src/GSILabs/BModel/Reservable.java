package GSILabs.BModel;

import java.util.Calendar;

/**
 * Esta clase se emplea como posible herencia para Bar y Restaurante
 * 
 * Cada Reserva incluye la fecha y hora en que se va a efectuar
 * Y un posible porcentaje de descuento
 * 
 * @author David Arbea
 */
public class Reservable {
    
    //Fecha de la reserva
    private Calendar fecha;
    
    /*
    Calendar es una clase abstracta que nos sirve para operar con fechas, horas y minutos
    set(int year, int month, int date, int hourOfDay, int minute)
    Sets the values for the calendar fields YEAR, MONTH, DAY_OF_MONTH, HOUR_OF_DAY, and MINUTE.
    Para + info visitar:
    https://docs.oracle.com/javase/7/docs/api/java/util/Calendar.html
    */
    
    //Posible descuento aplicado a la reserva
    private double descuento;
    
    ///Constructores
    public Reservable(Calendar fecha, int descuento) {
        this.fecha = fecha;
        this.descuento = descuento;
    }
    
    public Reservable(){
        
    }
    ///Getters y setters
    public Calendar getFecha() {
        return fecha;
    }

    public void setFecha(Calendar fecha) {
        this.fecha = fecha;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }
    
    
}
