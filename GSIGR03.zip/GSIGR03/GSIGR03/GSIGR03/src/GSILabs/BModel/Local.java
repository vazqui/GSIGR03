/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSILabs.BModel;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alumno
 */
public class Local {
    List<Propietario> propietarios; //Lista con los propietarios que tiene el local

    /**
     * Constructor
     */
    public Local() {
        propietarios = new ArrayList<>();
    }

    /**
     * Devuelve una lista con los propietarios del local
     * @return 
     */
    public List<Propietario> getPropietarios() {
        return propietarios;
    }
    
    /**
     * Añade un propietario a la lista de propietarios del local
     * @param p propietario que se va a añadir 
     */
    public void añadirPropietario(Propietario p){
        
        if(propietarios.size() > 2) System.out.println("No se puede añadir propietario. Numero maximo ya alcanzado.");
        else propietarios.add(p);
    }
    
    public void eliminarPropietario(Propietario p){
        if(propietarios.isEmpty()) System.out.println("No se puede eliminar propietario. La lista esta vacia");
    }
}
