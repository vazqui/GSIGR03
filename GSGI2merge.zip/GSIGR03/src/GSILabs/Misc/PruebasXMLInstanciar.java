/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSILabs.Misc;

import GSILabs.BModel.Local;
import GSILabs.BSystem.BusinessSystem;
import static GSILabs.BSystem.BusinessSystem.parseXMLFile;
import java.io.File;

/**
 *
 * @author alumno
 */
public class PruebasXMLInstanciar {
    public static void main(String[] args){
        String ruta = "local.xml";
        File f = new File (ruta);
        BusinessSystem almacenamiento;
        almacenamiento = parseXMLFile(f);
        for (Local local : almacenamiento.almacenamiento.locales) {
            System.out.println(local.descripcion + local.nombre + local.direccion.calle);
        }
        //System.out.println(almacenamiento.almacenamiento.locales.toString());
    }
}
