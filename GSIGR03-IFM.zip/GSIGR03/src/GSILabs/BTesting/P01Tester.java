/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSILabs.BTesting;

import GSILabs.BModel.*;
import GSILabs.BSystem.*;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author fiall
 */
public class P01Tester {

    public static void main(String[] args) {
        BussinessSystem system = new BussinessSystem();

        /**
         * S1
         */
        Usuario u1 = new Usuario("efseven", "1234", "2001/12/22");
        system.nuevoUsuario(u1);
        
        System.out.println(system.obtenerUsuario("efseven").toString());

        /**
         * S2
         */
        if (system.existeNick("nada")) {
            System.out.println("existe");
        } else {
            System.out.println("no existe");
        }

        /**
         * S3
         */
        Local l1 = new Local("Cañas", "Comunidad Foral de Navarra, Navarra, Calle Perez Goyena, 16");
        Local l2 = new Local("Brujas", "Comunidad Foral de Navarra, Navarra, Calle Perez Goyena, 16");

        system.nuevoLocal(l1);
        system.nuevoLocal(l2);

        /**
         * S4
         */
        system.eliminarLocal(l1);
        system.nuevoLocal(l2);

        /**
         * S5
         */
        Usuario u2 = new Usuario("efseven2", "1234", "2012/12/01");
        system.nuevoUsuario(u2);

        /**
         * S6-S7
         */
        Cliente c1 = new Cliente("efseven2", "1234", "2001/12/01");
        Bar b1 = new Bar("Cañas", "Comunidad Foral de Navarra, Navarra, Calle Perez Goyena, 16");
        system.nuevaReserva(c1, b1, LocalDate.now(), LocalTime.NOON);
        
        /**
         * S8
         */
        

    }
}
