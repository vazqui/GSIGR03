/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSILabs.BModel;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author alumno
 */
public class Cliente extends Usuario{
    public Set<Review> reviews; //Reviews escritas por el cliente
    public Set<Reserva> reservas;
    
    public Cliente(String nick, String password, String fechaNacimiento) {
        super(nick, password, fechaNacimiento);
        reviews = new HashSet<>();
        reservas = new HashSet<>();
    }
    
}
