/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSILabs.BModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author alumno
 */
public class Usuario {

    public String nick;
    public String password;
    public String fechaNacimiento;

    //Constructor
    public Usuario(String nick, String password, String fechaNacimiento) {
        if (comprobarLongitudNick(nick) && comprobarEdadUsuarios(fechaNacimiento)) {
            this.nick = nick;
            this.password = password;
            this.fechaNacimiento = fechaNacimiento;
        } 
    }

    //Comprueba que la longitud del nick sea menor que 3
    public boolean comprobarLongitudNick(String nick) {
        if (nick.length() < 3) {
            System.out.println("ERROR el nombre debe tener minimo 3 caracteres");
            return false;
        }
        return true;
    }

    //comprueba que los usuarios sean mayores de 14 años
    public boolean comprobarEdadUsuarios(String fecha) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        try {
            int edad = (int) ((TimeUnit.DAYS.convert(((new Date()).getTime() - sdf.parse(fecha).getTime()), TimeUnit.MILLISECONDS)) / 365);
            if (edad < 14) {
                System.out.println("ERROR el usuario debe tener mínimo 14 años");
                return false;
            }
            return true;
        } catch (ParseException e) {
            System.out.println("ERROR la fecha introducida no es correcta");
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        if (!Objects.equals(this.nick, other.nick)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "El usuario es " + nick;
    }
}
