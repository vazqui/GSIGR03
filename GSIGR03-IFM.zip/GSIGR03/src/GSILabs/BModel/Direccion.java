/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSILabs.BModel;

import java.util.Objects;

/**
 *
 * @author alumno
 */
public class Direccion {
    
    //Propiedades de la direccion
    
    public String localidad;     //Localidad donde se ubica el local
    public String provincia;     //Provincia donde se ubica el local
    public String calle;         //Calle donde se ubica el local 
    public String numero;        //Numero donde se ubica el local

    public Direccion(String direccion) {
        String[] partes = direccion.split(", ");
        localidad = partes[0];
        provincia = partes[1];
        calle = partes[2];
        numero = partes[3];
    }
    
    //Constructor para la clase direccion
    public Direccion(String localidad, String provincia, String calle, String numero) {
        this.localidad = localidad;
        this.provincia = provincia;
        this.calle = calle;
        this.numero = numero;
    }
    
    //Metodos de la direccion. Son getters y setters.
    
    //Get localidad del local
    public String getLocalidad() {
        return localidad;
    }



    //Get provincia del local
    public String getProvincia() {
        return provincia;
    }
    


    //Get calle del local
    public String getCalle() {
        return calle;
    }



    //Get numero del local
    public String getNumero() {
        return numero;
    }


    @Override
    public String toString(){
        return this.localidad + ", " + this.provincia + ", " + this.calle + ", " + this.numero;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Direccion other = (Direccion) obj;
        if (!Objects.equals(this.localidad, other.localidad)) {
            return false;
        }
        if (!Objects.equals(this.provincia, other.provincia)) {
            return false;
        }
        if (!Objects.equals(this.calle, other.calle)) {
            return false;
        }
        if (!Objects.equals(this.numero, other.numero)) {
            return false;
        }
        return true;
    }

}
