/*
 * Proyecto de Practicas
 * Gestion de Sistemas de Informacion
 * Curso Academico 21/22
 * Grupo GR03
 */
package GSILabs.BModel;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * Clase para el local
 *
 * @author GR03
 * @version 1.0
 */
public class Local {

    //Propiedades del local 
    public String nombre;        //Nombre del local
    public String descripcion;   //Breve descripcion del local, no mas de 300 caracteres
    public Direccion direccion;                    //Direccion del local
    public Set<Propietario> propietarios;          //Lista con los propietarios que tiene el local
    public Set<Review> reviews;

    //Constructor de la clase Local
    public Local(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = new Direccion(direccion);
        propietarios = new HashSet<>();
        reviews = new HashSet<>();
    }

    //Metodos de la clase Local
    //Funcion para comprobar la longitud de la descripcion
    public boolean comprobarDescripcion(String descripcion) {
        if (descripcion.length() > 300) {
            System.out.println("La descripcion es demasiado larga, tiene mas de 300 caracteres");
            return false;
        }
        return true;
    }

    public void añadirDescripcion(String d) {
        if (comprobarDescripcion(d)) {
            this.descripcion = d;
            System.out.println("Descripcion añadida.");
        }
    }

    /**
     * Devuelve una lista con los propietarios del local
     *
     * @return
     */
    public Set<Propietario> getPropietarios() {
        return propietarios;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Local other = (Local) obj;
        if (!Objects.equals(this.direccion, other.direccion)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Local{" + "nombre=" + nombre + ", direccion=" + direccion + '}';
    }

}
