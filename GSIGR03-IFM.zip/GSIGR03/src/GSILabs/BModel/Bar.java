/*
 * Proyecto de Practicas
 * Gestion de Sistemas de Informacion
 * Curso Academico 21/22
 * Grupo GR03
 */
package GSILabs.BModel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Clase para el Pub
 *
 * @author GR03
 * @version 1.0
 */
public class Bar extends Local implements Reservable {

    //Propiedades del Bar
    Set<Reserva> reservas;
    Set<String> tags;

    public Bar(String nombre, String direccion) {
        super(nombre, direccion);
        tags = new HashSet<>();
        reservas = new HashSet<>();
    }

}
