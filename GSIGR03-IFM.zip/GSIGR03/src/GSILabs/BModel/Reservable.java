package GSILabs.BModel;

import java.util.Calendar;

/*
 * Esta interfaz recoge la creacion de reservas para Bares y Restaurantes
 * 
 * Cada Reserva incluye la fecha y hora en que se va a efectuar
 * Y un posible porcentaje de descuento
 * 
 * @author David Arbea
 */
public interface Reservable {
    
    
    
    
}
