/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GSILabs.BSystem;

import GSILabs.BModel.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alumno
 */
public class BussinessSystem implements LeisureOffice {

    public BusinessData almacenamiento;

    public BussinessSystem() {
        this.almacenamiento = new BusinessData();
    }

    //**USUARIOS**//
    @Override
    public boolean nuevoUsuario(Usuario u) {
        try {
            if (existeNick(u.nick)) {
                System.out.println("No se puede añadir el usario. El nick ya existe.");
                return false;
            } else {
                almacenamiento.usuarios.add(u);
                System.out.println("Usuario " + u.nick + " añadido correctamente.");
                return true;
            }
        } catch (NullPointerException ex) {
            System.out.println("ERROR al crear usuario.");
            return false;
        }
    }

    @Override
    public boolean eliminaUsuario(Usuario u) {
        if (existeNick(u.nick)) {
            System.out.println("El usuario se ha eliminado correctamente.");
            almacenamiento.usuarios.remove(u);
            return false;
        } else {
            System.out.println("Usuario " + u.nick + " no existe, no se puede eliminar.");
            return true;
        }
    }

    @Override
    public boolean modificaUsuario(Usuario u, Usuario nuevoU) {
        if (eliminaUsuario(u) && nuevoUsuario(u)) {
            System.out.println("Usuario modificado correctamente.");
            return true;
        } else {
            System.out.println("El usuario no se ha podido modificar.");
            return false;
        }
    }

    @Override
    public boolean existeNick(String nick) {
        if (!almacenamiento.usuarios.isEmpty()) {
            for (Usuario usuario : almacenamiento.usuarios) {
                if (nick.contentEquals(usuario.nick)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public Usuario obtenerUsuario(String nick) {
        for (Usuario u : almacenamiento.usuarios) {
            if (nick.contentEquals(u.nick)) {
                return u;
            }
        }
        return null;
    }

    //**REVIEWS**//
    /**
     * Incorpora una nueva review al sistema, en caso de que sus datos (Usuario,
     * Local) sean correctos y no haya otra introducida para la misma fecha.
     *
     * @param r La review a introducir al sistema.
     * @return True si y solo si la operacion fue completada.
     */
    @Override
    public boolean nuevaReview(Review r) {
        if (true) {
            return true;
        } else {
            return false;
        }
    }

    public boolean eliminaReview(Review r) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean existeRewiew(Usuario u, Local l, LocalDate ld) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    //**CONTESTACIONES**//
    @Override
    public boolean nuevaContestacion(Contestacion c, Review r) {
        try {
            if (!tieneContestacion(r)) {
                r.añadirContestacion(c);
                System.out.println("Contestacion creada.");
                return true;
            } else {
                System.out.println("ERROR al crear respuesta.");
                return false;
            }
        } catch (NullPointerException ex) {
            System.out.println("ERROR al crear respuesta.");
            return false;
        }
    }

    @Override
    public boolean tieneContestacion(Review r) {
        if (r.respuesta == null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public Contestacion obtenerContestacion(Review r) {
        try {
            return r.respuesta;
        } catch (NullPointerException ex) {
            return null;
        }
    }

    @Override
    public boolean eliminaContestacion(Contestacion c) {
        try {
            for (Review review : almacenamiento.reviews) {
                if (review.respuesta.equals(c)) {
                    review.respuesta = null;
                    System.out.println("Contestacion eliminada correctamente.");
                    return true;
                } else {
                    System.out.println("ERROR al eliminar respuesta.");
                    return false;
                }
            }
        } catch (NullPointerException ex) {
            System.out.println("ERROR al eliminar respuesta.");
            return false;
        }
        return false;
    }

    @Override
    public boolean eliminaContestacion(Review r) {
        try {
            r.respuesta = null;
            System.out.println("Contestacion eliminada correctamente.");
            return true;
        } catch (NullPointerException ex) {
            System.out.println("ERROR al eliminar respuesta.");
            return false;
        }
    }

//**LOCALES**//
    @Override
    public boolean nuevoLocal(Local l) {
        for (Local local : almacenamiento.locales) {
            if (local.equals(l)) {
                System.out.println("En esta direccion ya hay un local.");
                return false;
            }
        }
        almacenamiento.locales.add(l);
        System.out.println("Local añadido correctamente.");
        return true;

    }

    @Override
    public boolean eliminarLocal(Local l) {

        for (Local local : almacenamiento.locales) {
            if (local.equals(l) && local.nombre.contentEquals(l.nombre)) {
                almacenamiento.locales.remove(l);
                System.out.println("Local eliminado correctamente.");
                return true;
            }
        }
        System.out.println("Local no encontrado, no se ha podido eliminar.");
        return false;

    }

    @Override
    public Local obtenerLocal(Direccion d) {
        for (Local local : almacenamiento.locales) {
            if (local.direccion.equals(d)) {
                System.out.println("Local encontrado.");
                return local;
            }
        }
        System.out.println("Local no encontrado.");
        return null;
    }

    @Override
    public boolean asociarLocal(Local l, Propietario p) {
        try {
            l.propietarios.add(p);
            System.out.println("Nuevo propietario para el local.");
            return true;
        } catch (NullPointerException ex) {
            System.out.println("ERROR al añadir propietario al local.");
            return false;
        }
    }

    @Override
    public boolean desasociarLocal(Local l, Propietario p) {
        try {
            l.propietarios.remove(p);
            System.out.println("Propietario desasociado de su local.");
            return true;
        } catch (NullPointerException ex) {
            System.out.println("ERROR al quitar propietario.");
            return false;
        }
    }

    @Override
    public boolean actualizarLocal(Local viejoL, Local nuevoL) {
        try {
            eliminarLocal(viejoL);
            nuevoLocal(nuevoL);
            System.out.println("Local actualizado.");
            return true;
        } catch (NullPointerException ex) {
            System.out.println("ERROR al actualizar el local.");
            return false;
        }
    }

    //**Locales**//
    @Override
    public Review[] verReviews(Local l) {
        return (Review[]) l.reviews.toArray();
    }

    @Override
    public boolean nuevaReserva(Cliente c, Reservable r, LocalDate ld, LocalTime lt) {
        try {
            if (existeNick(c.nick)) {
                Reserva reserva = new Reserva(c, ld, lt, r);
                almacenamiento.reservas.add(reserva);
                System.out.println("Reserva creada correctamente.");
                return true;
            } else {
                System.out.println("ERROR al crear reserva.");
                return false;
            }
        } catch (NullPointerException ex) {
            return false;
        }
    }

    @Override
    public Reserva[] obtenerReservas(Cliente c) {
        return (Reserva[]) c.reservas.toArray();
    }

    @Override
    public Reserva[] obtenerReservas(Reservable r) {
        try {
            List<Reserva> aux = new ArrayList<>();
            for (Reserva reserva : almacenamiento.reservas) {
                if (reserva.getReservable().equals(r)) {
                    aux.add(reserva);
                }
            }
            return (Reserva[]) aux.toArray();
        } catch (NullPointerException ex) {
            return null;
        }
    }

    @Override
    public Reserva[] obtenerReservas(LocalDate ld) {
        try {
            List<Reserva> aux = new ArrayList<>();
            for (Reserva reserva : almacenamiento.reservas) {
                if (reserva.getFecha().equals(ld)) {
                    aux.add(reserva);
                }
            }
            return (Reserva[]) aux.toArray();
        } catch (NullPointerException ex) {
            return null;
        }
    }

    @Override
    public boolean eliminarReserva(Reserva r) {
        try {
            almacenamiento.reservas.remove(r);
            System.out.println("Reserva eliminada correctamente.");
            return true;
        } catch (NullPointerException ex) {
            System.out.println("ERROR al eliminar reserva.");
            return false;
        }
    }

    @Override
    public Local[] listarLocales(String ciudad, String provincia) {
        try {
            List aux = new ArrayList<>();
            for (Local l : almacenamiento.locales) {
                if (l.direccion.localidad.contentEquals(ciudad) && l.direccion.provincia.contentEquals(provincia)) {
                    aux.add(l);
                }
            }
            return (Local[]) aux.toArray();
        } catch (NullPointerException ex) {
            return null;
        }
    }

    @Override
    public Bar[] listarBares(String ciudad, String provincia) {
        try {
            List aux = new ArrayList<>();
            for (Local l : almacenamiento.locales) {
                if (l.getClass().getName().contentEquals("GSILabs.BModel.Bar")) {
                    aux.add(l);
                }
            }
            return (Bar[]) aux.toArray();
        } catch (NullPointerException ex) {
            return null;
        }
    }

    @Override
    public Restaurante[] listarRestaurantes(String ciudad, String provincia) {
        try {
            List aux = new ArrayList<>();
            for (Local l : almacenamiento.locales) {
                if (l.getClass().getName().contentEquals("GSILabs.BModel.Restaurante")) {
                    aux.add(l);
                }
            }
            return (Restaurante[]) aux.toArray();
        } catch (NullPointerException ex) {
            return null;
        }
    }

    @Override
    public Pub[] listarPubs(String ciudad, String provincia) {
        try {
            List aux = new ArrayList<>();
            for (Local l : almacenamiento.locales) {
                if (l.getClass().getName().contentEquals("GSILabs.BModel.Pub")) {
                    aux.add(l);
                }
            }
            return (Pub[]) aux.toArray();
        } catch (NullPointerException ex) {
            return null;
        }
    }
}
